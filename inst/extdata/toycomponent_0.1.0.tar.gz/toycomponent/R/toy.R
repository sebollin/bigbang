toy_value <- function() 42L
